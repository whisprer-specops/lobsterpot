// src/ml/ganglion/mod.rs
pub mod network;
pub mod layers;
pub mod cellular;
pub mod trainer;