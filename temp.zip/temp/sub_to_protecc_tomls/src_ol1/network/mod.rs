// src/network/mod.rs
pub mod monitor;
pub mod features;  // For packet feature extraction
pub mod firewall;  // Moving firewall-related code here makes sense